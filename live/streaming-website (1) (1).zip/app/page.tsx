"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import {
  MessageCircle,
  ThumbsUp,
  Share2,
  Eye,
  Play,
  Pause,
  Settings,
  Volume2,
  SkipForward,
  SkipBack,
  Maximize,
  VolumeX,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

declare global {
  interface Window {
    YT: any
    onYouTubeIframeAPIReady: () => void
  }
}

export default function StreamingWebsite() {
  const [isLive, setIsLive] = useState(true)
  const [viewerCount, setViewerCount] = useState(1247)
  const [isPlaying, setIsPlaying] = useState(false)
  const [showControls, setShowControls] = useState(true)
  const [quality, setQuality] = useState("720p")
  const [volume, setVolume] = useState([80])
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [progress, setProgress] = useState([0])
  const [isSeeking, setIsSeeking] = useState(false)
  const [player, setPlayer] = useState<any>(null)
  const [playerReady, setPlayerReady] = useState(false)
  const playerRef = useRef<HTMLDivElement>(null)
  const controlsTimeoutRef = useRef<NodeJS.Timeout>()
  const progressUpdateRef = useRef<NodeJS.Timeout>()

  const [comments, setComments] = useState([
    { id: 1, user: "User123", message: "Great stream!", time: "2 min ago" },
    { id: 2, user: "StreamFan", message: "Love this content", time: "5 min ago" },
    { id: 3, user: "Viewer456", message: "Keep it up!", time: "8 min ago" },
  ])
  const [newComment, setNewComment] = useState("")

  useEffect(() => {
    const interval = setInterval(() => {
      setViewerCount((prev) => prev + Math.floor(Math.random() * 10) - 5)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    // Check if YouTube API is already loaded
    if (window.YT && window.YT.Player) {
      initializePlayer()
      return
    }

    // Load YouTube IFrame API
    const tag = document.createElement("script")
    tag.src = "https://www.youtube.com/iframe_api"
    tag.async = true
    const firstScriptTag = document.getElementsByTagName("script")[0]
    firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag)

    // Set up the callback
    window.onYouTubeIframeAPIReady = initializePlayer

    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current)
      }
      stopProgressTracking()
    }
  }, [])

  const initializePlayer = () => {
    if (!window.YT || !window.YT.Player) {
      console.error("YouTube API not loaded")
      return
    }

    try {
      const ytPlayer = new window.YT.Player("youtube-player", {
        height: "100%",
        width: "100%",
        videoId: "KxNP_Grtrj8",
        playerVars: {
          autoplay: 0,
          controls: 0,
          showinfo: 0,
          rel: 0,
          modestbranding: 1,
          disablekb: 1,
          fs: 0,
          iv_load_policy: 3,
          cc_load_policy: 0,
          playsinline: 1,
          enablejsapi: 1,
          origin: typeof window !== "undefined" ? window.location.origin : "",
        },
        events: {
          onReady: (event: any) => {
            console.log("Player ready")
            setPlayer(event.target)
            setPlayerReady(true)
            event.target.setVolume(volume[0])

            // Get video duration
            const videoDuration = event.target.getDuration()
            if (videoDuration > 0) {
              setDuration(videoDuration)
              setIsLive(false)
            }
          },
          onStateChange: (event: any) => {
            console.log("State changed:", event.data)
            if (event.data === window.YT.PlayerState.PLAYING) {
              setIsPlaying(true)
              startProgressTracking(event.target)
            } else if (event.data === window.YT.PlayerState.PAUSED) {
              setIsPlaying(false)
              stopProgressTracking()
            } else if (event.data === window.YT.PlayerState.ENDED) {
              setIsPlaying(false)
              stopProgressTracking()
            }
          },
          onError: (event: any) => {
            console.error("YouTube player error:", event.data)
          },
        },
      })
    } catch (error) {
      console.error("Error initializing YouTube player:", error)
    }
  }

  const startProgressTracking = (ytPlayer: any) => {
    stopProgressTracking()
    progressUpdateRef.current = setInterval(() => {
      if (ytPlayer && !isSeeking && typeof ytPlayer.getCurrentTime === "function") {
        try {
          const current = ytPlayer.getCurrentTime()
          const total = ytPlayer.getDuration()
          setCurrentTime(current)
          if (total > 0) {
            setDuration(total)
            setProgress([(current / total) * 100])
          }
        } catch (error) {
          console.error("Error updating progress:", error)
        }
      }
    }, 1000)
  }

  const stopProgressTracking = () => {
    if (progressUpdateRef.current) {
      clearInterval(progressUpdateRef.current)
    }
  }

  useEffect(() => {
    if (player && playerReady) {
      try {
        if (isMuted) {
          player.mute()
        } else {
          player.unMute()
          player.setVolume(volume[0])
        }
      } catch (error) {
        console.error("Error setting volume:", error)
      }
    }
  }, [volume, isMuted, player, playerReady])

  const handlePlayPause = () => {
    if (!player || !playerReady) {
      console.log("Player not ready")
      return
    }

    try {
      if (isPlaying) {
        player.pauseVideo()
        console.log("Pausing video")
      } else {
        player.playVideo()
        console.log("Playing video")
      }
    } catch (error) {
      console.error("Error in play/pause:", error)
    }
  }

  const handleSeek = (newProgress: number[]) => {
    if (!player || !playerReady || duration <= 0) return

    try {
      const seekTime = (newProgress[0] / 100) * duration
      player.seekTo(seekTime, true)
      setCurrentTime(seekTime)
      setProgress(newProgress)
    } catch (error) {
      console.error("Error seeking:", error)
    }
  }

  const handleSeekStart = () => {
    setIsSeeking(true)
    stopProgressTracking()
  }

  const handleSeekEnd = () => {
    setIsSeeking(false)
    if (player && isPlaying) {
      startProgressTracking(player)
    }
  }

  const handleSkip = (seconds: number) => {
    if (!player || !playerReady || duration <= 0) return

    try {
      const newTime = Math.max(0, Math.min(duration, currentTime + seconds))
      player.seekTo(newTime, true)
      setCurrentTime(newTime)
      setProgress([(newTime / duration) * 100])
    } catch (error) {
      console.error("Error skipping:", error)
    }
  }

  const handleQualityChange = (newQuality: string) => {
    setQuality(newQuality)
    if (!player || !playerReady) return

    try {
      const qualityMap: { [key: string]: string } = {
        "1080p": "hd1080",
        "720p": "hd720",
        "480p": "large",
        "360p": "medium",
        "240p": "small",
      }
      player.setPlaybackQuality(qualityMap[newQuality])
    } catch (error) {
      console.error("Error changing quality:", error)
    }
  }

  const handleVolumeToggle = () => {
    setIsMuted(!isMuted)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const showControlsTemporarily = () => {
    setShowControls(true)
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current)
    }
    controlsTimeoutRef.current = setTimeout(() => {
      setShowControls(false)
    }, 3000)
  }

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (newComment.trim()) {
      const comment = {
        id: comments.length + 1,
        user: "You",
        message: newComment,
        time: "now",
      }
      setComments([comment, ...comments])
      setNewComment("")
    }
  }

  const handleVideoClick = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    handlePlayPause()
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-purple-400">ManekingIdol</h1>
              <Badge
                variant="secondary"
                className={isLive ? "bg-red-600 text-white animate-pulse" : "bg-blue-600 text-white"}
              >
                {isLive ? "LIVE" : "VOD"}
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Eye className="w-4 h-4" />
                <span className="text-sm">{viewerCount.toLocaleString()} viewers</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Video Section */}
          <div className="lg:col-span-3">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-0">
                {/* Video Player */}
                <div
                  className="relative aspect-video bg-black rounded-t-lg overflow-hidden cursor-pointer"
                  onMouseMove={showControlsTemporarily}
                  onMouseEnter={showControlsTemporarily}
                  ref={playerRef}
                >
                  <div id="youtube-player" className="w-full h-full" />

                  {/* Overlay to prevent direct YouTube access */}
                  <div
                    className="absolute inset-0 z-10 bg-transparent"
                    onContextMenu={(e) => e.preventDefault()}
                    onClick={handleVideoClick}
                    style={{
                      pointerEvents: showControls ? "none" : "auto",
                    }}
                  />

                  {/* Custom Controls Overlay */}
                  <div
                    className={`absolute inset-0 z-20 bg-gradient-to-t from-black/70 via-transparent to-transparent transition-opacity duration-300 ${
                      showControls ? "opacity-100" : "opacity-0"
                    }`}
                    style={{ pointerEvents: showControls ? "auto" : "none" }}
                  >
                    {/* Play/Pause Button */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button
                        variant="ghost"
                        size="lg"
                        className="bg-black/50 hover:bg-black/70 text-white rounded-full p-4 backdrop-blur-sm"
                        onClick={handlePlayPause}
                        disabled={!playerReady}
                      >
                        {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
                      </Button>
                    </div>

                    {/* Bottom Controls */}
                    <div className="absolute bottom-0 left-0 right-0 p-4 space-y-2 bg-gradient-to-t from-black/80 to-transparent">
                      {/* Progress Bar */}
                      {!isLive && duration > 0 && (
                        <div className="w-full">
                          <Slider
                            value={progress}
                            onValueChange={(value) => {
                              setProgress(value)
                              if (isSeeking) {
                                const seekTime = (value[0] / 100) * duration
                                setCurrentTime(seekTime)
                              }
                            }}
                            onValueCommit={handleSeek}
                            onPointerDown={handleSeekStart}
                            onPointerUp={handleSeekEnd}
                            max={100}
                            step={0.1}
                            className="cursor-pointer"
                            disabled={!playerReady}
                          />
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-white hover:bg-white/20 p-2"
                            onClick={handlePlayPause}
                            disabled={!playerReady}
                          >
                            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                          </Button>

                          {/* Skip Controls */}
                          {!isLive && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-white hover:bg-white/20 p-2"
                                onClick={() => handleSkip(-10)}
                                disabled={!playerReady}
                              >
                                <SkipBack className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-white hover:bg-white/20 p-2"
                                onClick={() => handleSkip(10)}
                                disabled={!playerReady}
                              >
                                <SkipForward className="w-4 h-4" />
                              </Button>
                            </>
                          )}

                          {/* Volume Control */}
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-white hover:bg-white/20 p-2"
                              onClick={handleVolumeToggle}
                              disabled={!playerReady}
                            >
                              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                            </Button>
                            <div className="w-20">
                              <Slider
                                value={volume}
                                onValueChange={(value) => {
                                  setVolume(value)
                                  if (value[0] === 0) {
                                    setIsMuted(true)
                                  } else {
                                    setIsMuted(false)
                                  }
                                }}
                                max={100}
                                step={1}
                                className="cursor-pointer"
                                disabled={isMuted || !playerReady}
                              />
                            </div>
                            <span className="text-xs text-white w-8 text-center">
                              {isMuted ? "0%" : `${volume[0]}%`}
                            </span>
                          </div>

                          {/* Time Display */}
                          {!isLive && duration > 0 && (
                            <div className="text-xs text-white font-mono">
                              {formatTime(currentTime)} / {formatTime(duration)}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center space-x-2">
                          {/* Quality Selector */}
                          <div className="flex items-center space-x-2">
                            <Settings className="w-4 h-4 text-white" />
                            <Select value={quality} onValueChange={handleQualityChange} disabled={!playerReady}>
                              <SelectTrigger className="w-20 h-8 bg-black/50 border-white/20 text-white text-xs backdrop-blur-sm">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-gray-800 border-gray-600 backdrop-blur-sm">
                                <SelectItem value="1080p" className="text-white hover:bg-gray-700">
                                  1080p
                                </SelectItem>
                                <SelectItem value="720p" className="text-white hover:bg-gray-700">
                                  720p
                                </SelectItem>
                                <SelectItem value="480p" className="text-white hover:bg-gray-700">
                                  480p
                                </SelectItem>
                                <SelectItem value="360p" className="text-white hover:bg-gray-700">
                                  360p
                                </SelectItem>
                                <SelectItem value="240p" className="text-white hover:bg-gray-700">
                                  240p
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {/* Fullscreen Button */}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-white hover:bg-white/20 p-2"
                            onClick={() => {
                              if (playerRef.current) {
                                if (document.fullscreenElement) {
                                  document.exitFullscreen()
                                } else {
                                  playerRef.current.requestFullscreen()
                                }
                              }
                            }}
                          >
                            <Maximize className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Live/VOD indicator */}
                  <div className="absolute top-4 left-4 z-30">
                    <Badge className={isLive ? "bg-red-600 text-white animate-pulse" : "bg-blue-600 text-white"}>
                      {isLive ? "🔴 LIVE" : "📹 VOD"}
                    </Badge>
                  </div>

                  {/* Quality indicator */}
                  <div className="absolute top-4 right-4 z-30">
                    <Badge variant="secondary" className="bg-black/50 text-white backdrop-blur-sm">
                      {quality}
                    </Badge>
                  </div>

                  {/* Player Status */}
                  {!playerReady && (
                    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/50">
                      <div className="text-white text-center">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-2"></div>
                        <p>Loading player...</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Video Info */}
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-2">
                    {isLive ? "Live Stream - Entertainment Content" : "Video Content - Entertainment"}
                  </h2>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=40&width=40" />
                        <AvatarFallback>MI</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">ManekingIdol Channel</p>
                        <p className="text-sm text-gray-400">
                          {isLive ? "Live streaming now" : `Duration: ${formatTime(duration)}`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <ThumbsUp className="w-4 h-4 mr-2" />
                        Like
                      </Button>
                      <Button variant="outline" size="sm">
                        <Share2 className="w-4 h-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </div>
                  <p className="text-gray-300 text-sm">
                    {isLive
                      ? "Welcome to our live stream! Enjoy the content and don't forget to interact in the chat. Use custom controls to pause, adjust volume, and change quality."
                      : "Enjoy this video content! Use the playback controls to pause, seek, and adjust quality as needed. All controls are custom-made for the best viewing experience."}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat/Comments Section */}
          <div className="lg:col-span-1">
            <Card className="bg-gray-800 border-gray-700 h-[600px] flex flex-col">
              <div className="p-4 border-b border-gray-700">
                <h3 className="font-semibold flex items-center">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  {isLive ? "Live Chat" : "Comments"}
                </h3>
              </div>

              {/* Comments List */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {comments.map((comment) => (
                  <div key={comment.id} className="text-sm">
                    <div className="flex items-start space-x-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="text-xs">{comment.user[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-purple-400">{comment.user}</span>
                          <span className="text-xs text-gray-500">{comment.time}</span>
                        </div>
                        <p className="text-gray-300 mt-1">{comment.message}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Comment Input */}
              <div className="p-4 border-t border-gray-700">
                <form onSubmit={handleCommentSubmit} className="flex space-x-2">
                  <Input
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder={isLive ? "Type a message..." : "Add a comment..."}
                    className="flex-1 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                  />
                  <Button type="submit" size="sm">
                    Send
                  </Button>
                </form>
              </div>
            </Card>
          </div>
        </div>

        {/* Related Videos */}
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4">Related Content</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors cursor-pointer">
                <CardContent className="p-0">
                  <div className="aspect-video bg-gray-700 rounded-t-lg relative">
                    <img
                      src={`/placeholder.svg?height=180&width=320&query=video thumbnail ${i}`}
                      alt={`Related video ${i}`}
                      className="w-full h-full object-cover rounded-t-lg"
                    />
                    <Badge className="absolute top-2 right-2 bg-red-600 text-white text-xs">
                      {i % 2 === 0 ? "LIVE" : "VOD"}
                    </Badge>
                    {i % 2 !== 0 && (
                      <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-1 rounded">
                        {Math.floor(Math.random() * 60) + 10}:00
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h4 className="font-medium text-sm mb-1 line-clamp-2">
                      {i % 2 === 0 ? `Live Stream ${i}` : `Video Content ${i}`} - Entertainment
                    </h4>
                    <p className="text-xs text-gray-400">
                      {i % 2 === 0
                        ? `${Math.floor(Math.random() * 500) + 100} viewers`
                        : `${Math.floor(Math.random() * 10000) + 1000} views • ${Math.floor(Math.random() * 7) + 1} days ago`}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
